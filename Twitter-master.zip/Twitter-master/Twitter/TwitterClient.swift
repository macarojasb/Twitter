//
//  TwitterClient.swift
//  Twitter
//
//  Created by Maca A. Rojas Bustamante on 2/23/16.
//  Copyright © 2016 codepath. All rights reserved.
//

import UIKit
import BDBOAuth1Manager

class TwitterClient: BDBOAuth1SessionManager {

    static let sharedInstance = TwitterClient(baseURL: NSURL(string: "https://api.twitter.com")!, consumerKey: "achL3zEfiT7A6jvnMI8BLU6l1", consumerSecret: "t8YWTseYOXjG08qSD8Q5JTXEz1LpQX4V5Wc2zbAe8hfDP2MjI4")
    
    func login(
    
        TwitterClient.sharedInstance.deauthorize()
        TwitterClient.sharedInstance.fetchRequestTokenWithPath("oauth/request_token", method: "GET", callbackURL: NSURL(string: "mytwitterdemo://oauth"), scope: nil, success: { (resquestToken: BDBOAuth1Credential!) -> Void in
        
        
        let url = NSURL(string: "https://api.twitter.com/oauth/authorize?oauth_token=\(resquestToken.token)")!
        UIApplication.sharedApplication().openURL(url)
        
        }) { (error: NSError!) -> Void in
        print("error: \(error.localizedDescription)")
    }
    
    func homeTimeline(success: ([Tweet]) ->(), failure: (NSError) -> ()) {
        
       GET("1.1/statuses/home_timeline.json", parameters: nil, progress: nil, success: { (task: NSURLSessionDataTask?, response: AnyObject? ) -> Void in
            
            let dictionaries = response as! [NSDictionary]
            let tweets = Tweet.tweetWithArray(dictionaries)
            
            success(tweets)
            }, failure: { (task: NSURLSessionDataTask?, error: NSError) -> Void in
                failure(error)
            })
    }
    
    func currentAccount () {
    
   GET("1.1/account/verify_credentials.json", parameters: nil, success: { (task: NSURLSessionDataTask, response: AnyObject?) -> Void in
    
    let userDictionary = response as! NSDictionary
    // print("user: \(user)")
    
    let user = User(dictionary: userDictionary)
    
    print("name: \(user.name)")
    print("screename \(user.screenname)")
    print("profile url: \(user.profileUrl)")
    print("description: \(user.tagline)")
    
    
    }, failure: { (task: NSURLSessionDataTask?, error: NSError) -> Void in
    
    })
        
    }
    
}
